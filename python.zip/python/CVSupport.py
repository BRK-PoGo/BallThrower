import cv2
import os
import numpy as np


print(cv2.__version__)


class CVSupport():
    #Public variables
    cap = None
    frame = None
    gray = None
    gausBlur = None
    frameWidth, frameHeight = (None, None)
    cap = None
    overwrite = False

    #Fearture Matching components
    bf = None
    orb = None

    sift = None
    surf = None

    tSift = None
    tSurf = None

    tSiKp = None
    tSuKp = None

    tSiDe = None
    tSuDe = None

    tbfKp = None
    tBfDe = None


    bfKp = None
    siKp = None
    suKp = None

    bfDe = None
    siDe = None
    suDe = None

    bfFrame = None
    siFrame = None
    suFrame = None

    featureEx = 'qrExample.png'
    exampleImage = None


    def __init__(self):
        print("Reached")
        self.cap = cv2.VideoCapture(1);
        ret, self.frame = self.cap.read()
        self.frameWidth = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)  # float
        self.frameHeight = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)  # float
        
        self.sift = cv2.xfeatures2d_SIFT.create()
        self.surf = cv2.xfeatures2d_SURF.create(hessianThreshold=100)

        self.orb = cv2.ORB_create()
        self.bf = cv2.BFMatcher(cv2.NORM_L1,crossCheck=False)


        if(os.path.exists(self.featureEx)):
            self.exampleImage = cv2.cvtColor(cv2.imread(self.featureEx), cv2.COLOR_BGR2GRAY)

            self.tSiKp, self.tSiDe = self.sift.detectAndCompute(self.exampleImage, None)
            self.tSuKp, self.tSuDe = self.surf.detectAndCompute(self.exampleImage, None)

            self.tBfKp, self.tBfDe = self.orb.detectAndCompute(self.exampleImage, None)


    def findMatch(self, procedure, frame):
        #Convert Frame to gray
        output = np.copy(frame)
        output = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
        keyp, desc = self.getFeaturePoints(procedure, output)

        if(desc is None):
            return frame

        if (procedure.lower() == "SIFT".lower()):
            matches = self.bf.knnMatch(self.tSiDe, desc, k=2)
        elif (procedure.lower() == "SURF".lower()):
            matches = self.bf.knnMatch(self.tSuDe, desc, k=2)
        else:
            if(len(desc) == 0):
                return frame
            matches = self.bf.knnMatch(self.tBfDe, desc, k=2)

        #matches = sorted(matches, key = lambda x:x.distance)

        #print("Reached 1")
        # Apply ratio test
        good = []
        c = []

        if(len(matches) < 2):
            return frame, []

        #print("Matches length: " + str(len(matches)))

        for m, n in matches:
            if m.distance < 0.5 * n.distance:
                good.append([m])
                c.append([n])
        print("#Good matches: " + str(len(good)))
        """
        print("KeyPoints:")
        for entry in c:
            print(entry)

        print("\nGood:")
        for entry in good:
            print(entry)

        print("\n")
        """
        frame = cv2.drawMatchesKnn(self.exampleImage, self.tSiKp, output, keyp, good, frame,flags = 2)
        return (frame, good)



    def drawFeaturePoints(self, frame, keyPoints):
        #print("Amount of keypoints: " + str(len(keyPoints)))
        output = np.copy(frame)
        cv2.drawKeypoints(frame, keyPoints, output)
        return output

    #Input mus be converted to gray
    def getFeaturePoints(self, procedure, Input):
        #gray = np.copy(Input)
        gray = Input
        #gray = cv2.blur(gray, (5, 5))


        if (procedure.lower() == "SIFT".lower()):
            #print("SIFT used")
            keyp, desc = self.sift.detectAndCompute(gray,None)  # For detect you would idealy pass a mask if your only interested
        elif (procedure.lower() == "SURF".lower()):
            #print("SURF used")
            keyp, desc = self.surf.detectAndCompute(gray, None)  # For detect you would idealy pass a mask if your only interested
        else:
            keyp, desc = self.orb.detectAndCompute(gray, None)
            if desc is None:
                return keyp, []

        return keyp, desc


    def update(self):
        ret, self.frame = self.cap.read()
        #self.applyBlur()
        self.applyGray()

    def applyBlur(self):
        kernelSize = (5,5)
        self.gausBlur = cv2.GaussianBlur(self.frame, (5, 5), 0)
        if(self.overwrite):
            self.frame = self.gausBlur

    def applyGray(self):
        self.gray = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)
        if(self.overwrite):
            self.frame = self.gray

    def getVideoFrame(self):
        self.update()
        return self.frame

    def getFrameDim(self):
        return self.frameHeight, self.frameWidth

    def terminate(self):
        self.cap.release()
        cv2.destroyAllWindows()





    #Surf matching

    #Sirf
