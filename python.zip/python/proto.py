from CVSupport import CVSupport
import cv2
from ColorSense import ColorDistance
import numpy as np
from _overlapped import NULL
import test


class Proto():


    def getDistance(self, frame, frameWidth, frameHeight):
        #Array that keeps all the HSV values in it
        #Each entry consists of 3 values. Order: [yelLow, yelHigh, redLow, redHigh]
        hsvValues = []
        erodDil = []




        hsvValues = [np.array([15, 145, 147]), np.array([31, 255, 210]), np.array([85, 149, 134]), np.array([179, 255, 255])]
        erodDil = [2,2, 0, 2]


        print("HSV Values: ")
        print("Color1: lower/upper: " + str(hsvValues[0]) +"/" + str(hsvValues[1]) + "\tDilation/erosion: " + str(erodDil[0]) + "/" + str(erodDil[1]))
        print("Color2: lower/upper: " + str(hsvValues[2]) +"/" + str(hsvValues[3]) + "\tDilation/erosion: " + str(erodDil[2]) + "/" + str(erodDil[3]))

        colDist = ColorDistance()
        cvSup = CVSupport()

        target = cv2.imread('qrExample.png')

        matchThreshold = 5

        frame = cvSup.getVideoFrame()

        

        BF, matches = cvSup.findMatch("SIFT", frame)
        
        
        display = colDist.getContourDistance(frame, frameWidth, frameHeight, hsvValues, erodDil, 3)
        if(len(matches) >= matchThreshold):
            distance = colDist.getTargetDistance()
            cv2.putText(frame, "Box detected", (230, 450), cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
        else:
            distance = "N/A"

        print("Distance Calculation: " + str(distance))


        return distance
        
    def getDistance2(self, frame, frameWidth, frameHeight):
        #Array that keeps all the HSV values in it
        #Each entry consists of 3 values. Order: [yelLow, yelHigh, redLow, redHigh]
        hsvValues = []
        erodDil = []




        hsvValues = [np.array([15, 145, 147]), np.array([31, 255, 210]), np.array([85, 149, 134]), np.array([179, 255, 255])]
        erodDil = [2,2, 0, 0]


        print("HSV Values: ")
        print("Color1: lower/upper: " + str(hsvValues[0]) +"/" + str(hsvValues[1]) + "\tDilation/erosion: " + str(erodDil[0]) + "/" + str(erodDil[1]))
        print("Color2: lower/upper: " + str(hsvValues[2]) +"/" + str(hsvValues[3]) + "\tDilation/erosion: " + str(erodDil[2]) + "/" + str(erodDil[3]))

        colDist = ColorDistance()
        cvSup = CVSupport()

        target = cv2.imread('qrExample.png')

        matchThreshold = 5

        frame = cvSup.getVideoFrame()

        

        BF, matches = cvSup.findMatch("SIFT", frame)
        
        
        display = colDist.getContourDistance(frame, frameWidth, frameHeight, hsvValues, erodDil, 3)
        if(len(matches) >= matchThreshold):
            distance = colDist.getTargetDistance()
            cv2.putText(frame, "Box detected", (230, 450), cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
        else:
            distance = "N/A"

        print("Distance Calculation: " + str(distance))


        return distance




"""
cap = cv2.VideoCapture(1);
ret, frame = cap.read()
prot = Proto()

found = False
dist = None

while(not found):
    
    dist = prot.getDistance(frame, cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    if(dist is "N/A"):
        print("Dist not found")
    else:    
        print("DIST:", dist)
        found = True

    if cv2.waitKey(5) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()
#test.calc(0, dist)


"""