import serial, time, subprocess

arduino = serial.Serial('COM7', 9600, timeout=.1)

time.sleep(1)

def doCommand(command):
    newcommand = command.encode(encoding='utf_8', errors='strict')   
    arduino.write(newcommand)
    run = True
    while run:
        data = arduino.readline()
        if data:
            string = data.__str__()
            print(string)
            if "Command completed" in string:
                run = False

def printAngles():
    command = 'print'
    doCommand(command)
    
def setAngles(angles):
    command = 'set ' + str(angles[0]) + ',' + str(angles[1]) + ',' + str(angles[2]) + ',' + str(angles[3])
    doCommand(command)
    
def setAngle(angle):
    command = 'angle ' + str(angle)
    doCommand(command)
    
def throw(times):
    command = 'throw ' + str(times)
    doCommand(command)
    
def calc(base, distanceVal):
    
    file1 = "distance.txt"
    file2 = "angles.txt"
    
    distanceInt = str(distanceVal)
    
    distance = open(file1, 'w')
    distance.write(distanceInt)
    distance.close()
    
    subprocess.call(['java', '-jar', 'executableANN.jar'])
    
    angles = open(file2, 'r')
    angString = angles.readline()
    angList = angString.split(" ")
    angList[0] = base
    angles.close()
    
    #angList = [0,70,-40,-45]
    setAngles(angList)
    printAngles()
    throw(1)    
    
    print("End of test")
    
#calc(0, 80)