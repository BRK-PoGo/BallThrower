import cv2
from msvcrt import getch

while(True):
    print("Hello There")

    if cv2.waitKey(5) & 0xFF == ord('q'):
        break

