import cv2
import time
import numpy as np
from platform import python_version
import test
from proto import Proto

#cap = cv2.VideoCapture(0)
capture = 1
skinColorUpper = (0,0,0)
skinColorLower = (0,0,0)

cv2.namedWindow('Colorbars', cv2.WINDOW_NORMAL)
cv2.resizeWindow('Colorbars', 400,400)
numberFingers = 0

def updateValues(x):
    pass

cv2.createTrackbar("HUE Min", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("HUE Min", "Colorbars", 31)
cv2.createTrackbar("HUE Max", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("HUE Max", "Colorbars", 60)
cv2.createTrackbar("SAT Min", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("SAT Min", "Colorbars", 0) 
cv2.createTrackbar("SAT Max", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("SAT Max", "Colorbars", 255) #60
cv2.createTrackbar("Light Min", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("Light Min", "Colorbars", 0) 
cv2.createTrackbar("Light Max", "Colorbars", 0, 255, updateValues)
cv2.setTrackbarPos("Light Max", "Colorbars", 255) #140              
    
    
#potentially use kanny edge detection --> finer recognition
def handMask(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV);
    maskhsv = cv2.inRange(hsv, (0, 0, 0), (50, 255, 255));
    
    ret, labels = cv2.connectedComponents(maskhsv, connectivity = 8)


    # Map component labels to hue val
    label_hue = np.uint8(179*labels/np.max(labels))
    blank_ch = 255*np.ones_like(label_hue)
    labeled_img = cv2.merge([label_hue, blank_ch, blank_ch])

    # cvt to BGR for display
    labeled_img = cv2.cvtColor(labeled_img, cv2.COLOR_HSV2BGR)

    # set bg label to black
    labeled_img[label_hue==0] = 0
  #  cv2.imshow('labeled.png', labeled_img)
    
 #   cv2.imshow('HSV', maskhsv)
    kernel = np.ones((5,5),np.uint8)
    opening = cv2.morphologyEx(maskhsv, cv2.MORPH_OPEN, kernel)
    kernel = np.ones((3,3),np.uint8)
    dilation = cv2.dilate(opening,kernel,iterations = 1)
    
    dst = cv2.GaussianBlur(dilation, (3,3), 1)
#    cv2.imshow('dst', dst)
#    _, thresholded = cv2.threshold(dst, 200, 255, cv2.THRESH_BINARY)
    _, thresholded = cv2.threshold(dst, 200, 255, cv2.THRESH_BINARY)

    
    
    ycbcr = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb);
    ycbcr = cv2.inRange(ycbcr, (0, 133, 77), (255,173,127));
#    y,cb,cr = cv2.split(ycbcr2);
#    crUp = (cr >= 0.3448*cb+76.2069)
#    ycbcr = crUp * ycbcr;
#    crUp = (cr >= -4.5652*cb+234.5652)
#    ycbcr = crUp * ycbcr;
#    crDown = (cr <= -1.15*cb+301.75)
#    ycbcr = crDown * ycbcr;
#    crDown = (cr <= -2.2857*cb)+432.85
#    ycbcr = crDown * ycbcr;
    
   # cv2.imshow("CopyYCbCr", ycbcr)    

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB);
    maskrgb = cv2.inRange(rgb, (95, 40, 20), (255,255,255));
    
    frameCopy = frame;
    maskCopy = cv2.inRange(frameCopy, (20, 40, 95), (255,255,255));
    b,g,r = cv2.split(frame);
    greater = abs(r-g) > 15;
    maskCopy = greater * maskCopy;
    greater = r > g;
    maskCopy = greater * maskCopy;
    greater = r > b;
    maskCopy = greater * maskCopy;
    greater = (np.maximum.reduce([b,g,r])-np.minimum.reduce([b,g,r])) > 15;
    maskCopy = greater * maskCopy;
    
    #cv2.imshow("Copy", maskCopy)    
    
    rangeMask = cv2.bitwise_and(ycbcr, maskCopy);
    #and2 = cv2.bitwise_and(and1, maskycbcr);
    
    #and1 = cv2.bitwise_and(maskrgb, mask2);
#    and2 = cv2.bitwise_and(mask3, mask4);
#    and3 = cv2.bitwise_and(and1, and2);
    #cv2.imshow('Conc', rangeMask) 

#    return thresholded
    
    imgHLS = cv2.cvtColor(frame, cv2.COLOR_BGR2HLS)
    rangeMask = cv2.inRange(imgHLS, skinColorLower, skinColorUpper)
    #5x5 fiter for blurring
    kernel = np.ones((9,9),np.uint8)
    #dialate and erode to remove holes
    erosion = cv2.erode(rangeMask, kernel, iterations = 1)
    kernel = np.ones((2,2),np.uint8)
    dilation = cv2.dilate(erosion,kernel,iterations = 4)
    dst = cv2.GaussianBlur(dilation, (7,7), 0)
#    _, thresholded = cv2.threshold(dst, 200, 255, cv2.THRESH_BINARY)
    _, thresholded = cv2.threshold(dst, 200, 255, cv2.THRESH_BINARY)    
    return thresholded

def getHandConvex(handMask, frame):
    #print("Handmask", handMask)
    _,contours, _ = cv2.findContours(handMask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            #Find the largest contour and draw it
    if(len(contours) <= 0):
        return [-1],[-1],[-1]
    c = max(contours, key = cv2.contourArea)
    C = [c]
#    print("C",C)
#    cv2.drawContours(frame, C, -1, (0,255,0), 3)
    x,y,w,h = cv2.boundingRect(c)
    # draw rectangle around the contours (in green)
    cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
  
    # for each contour
    for cnt in C:
        # get convex hull
        hull = cv2.convexHull(cnt)
        # draw it in red color
        cv2.drawContours(frame, [hull], -1, (0, 0, 255), 2)        
    
    defhull = cv2.convexHull(c, returnPoints=False)
    defects = cv2.convexityDefects(c,defhull)
#    print("c", c)
 #   print("hull",hull)
  #  print("defects",defects)
    
    return c, hull, defects

#cluster the corner points into 7 
def kMeans(frame, hull):
    if(len(hull)<=6):
        return
    Z = np.vstack(hull)
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    ret,label,center=cv2.kmeans(Z,7,None,criteria,10,cv2.KMEANS_PP_CENTERS)        
    
    #K-Menans cluster of the corner points 
    #for p in center:
    #    cv2.circle(frame, (p[0],p[1]), 4, (255,0,0), 2)
        
    return center

def unit_vector(vector):
    """ Returns the unit vector of the vector.  """
    return vector / np.linalg.norm(vector)

def angle_between(v1, v2):
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))

def findFingers(start, end, far):
#    maxAngleDeg = 100
    maxAngleDeg = 80
    #print(start)
    a = np.array(start)
    b = np.array(end)
    c = np.array(far)

    x = np.array(c-a)
    y = np.array(c-b)

    radangle = angle_between(x, y)
    angle = np.degrees(radangle)
#    cv2.putText(frame, str(int(angle)), end, cv2.FONT_HERSHEY_PLAIN, 1, (0,0,0), 2, cv2.LINE_AA, False)    
    return angle < maxAngleDeg
    
def hullDefect(frame, c, defects):
    numberFingers = 1
    try:
        if not hasattr(defects, 'shape'):
            return
        for i in range(defects.shape[0]):
        
            s,e,f,_ = defects[i,0]
            start = tuple(c[s][0])
            end = tuple(c[e][0])
            far = tuple(c[f][0])
            cv2.line(frame,far,end,[255,255,0],2)
            cv2.line(frame,far,start,[255,255,0],2)
            cv2.circle(frame,far,4,[0,255,255],2)    
            cv2.circle(frame,start,4,[255,255,255],2)    
            if(findFingers(start, end, far)):
                numberFingers += 1
        return numberFingers
    except NameError:
        return
    else:
        return

    
def updateTrackbar(): 
    hmin = cv2.getTrackbarPos('HUE Min', 'Colorbars')
    hmax = cv2.getTrackbarPos('HUE Max', 'Colorbars')
    smin = cv2.getTrackbarPos('SAT Min', 'Colorbars')
    smax = cv2.getTrackbarPos('SAT Max', 'Colorbars')
    lmin = cv2.getTrackbarPos('Light Min', 'Colorbars')
    lmax = cv2.getTrackbarPos('Light Max', 'Colorbars')
    skinColorLower = (hmin, smin, lmin)
    skinColorUpper = (hmax, smax, lmax)
    return skinColorLower, skinColorUpper
 
start = time.time()

cap = cv2.VideoCapture(0)

while(cap.isOpened() and capture == 1):
    skinColorLower, skinColorUpper = updateTrackbar()
    #print "OpenCV version :  {0}".format(cv2.__version__)
    #python version 2.7.15
    
    #TODO: Look into image averaging
    ret, frame = cap.read()
    if ret==True:
        frame = cv2.flip(frame,1)
        mask = handMask(frame)
        cv2.imshow('mask2', mask)
#        print("mask" , mask)
 #       print("frame" , frame)
        contours, hull, defects = getHandConvex(mask, frame)
        if(len(contours) <= 1):
            continue
        center = kMeans(frame, hull)
        finger = hullDefect(frame, contours, defects)
#        cv2.putText(frame, str(finger) ,(619,351), 1,(0,0,255),2,cv2.LINE_AA)
        cv2.rectangle(frame, (0,0), (55,55), (255,255,255), cv2.FILLED)
        cv2.putText(frame, str(finger), (0, 55), cv2.FONT_HERSHEY_PLAIN, 5, (0,0,0), 4, cv2.LINE_AA, False)
        cv2.imshow("Frame1", frame)
        #cv2.imshow('frame',frame)
        if(finger is None):
            start = time.time()
            continue

        if(finger < 5):
            start = time.time()
        if((time.time() - start) > 2):
            print("Shoot")
            cap2 = cv2.VideoCapture(1)
            ret2, frame2 = cap2.read()
            prot = Proto()
            
            
            print("Camera Width:", cv2.CAP_PROP_FRAME_WIDTH)
            dist = prot.getDistance(frame2, cap2.get(cv2.CAP_PROP_FRAME_WIDTH), cap2.get(cv2.CAP_PROP_FRAME_HEIGHT))
            
            #st = time.time()
            #timeout = 1
            while(dist == "N/A"):# and (time.time() - st < timeout)):
                print("Distance not yet found.")
                ret2, frame2 = cap2.read()
                dist = prot.getDistance(frame2, cap2.get(cv2.CAP_PROP_FRAME_WIDTH), cap2.get(cv2.CAP_PROP_FRAME_HEIGHT))
            print("distance:", dist)
            
            
            cap2.release()

            start = time.time();
            test.calc(0, dist)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            capture = 0

# Release everything if job is finished
cap.release()
#out.release()
cv2.destroyAllWindows()