#What you need installed
import cv2
import numpy as np
import math
import os

#My custom classes
from CVSupport import CVSupport
from ColorSense import ColorTuner, ColorDistance

#Also please set the path to the QR-Code correctly in CVSupport
#Look for te variable 'featureEx'


# Finally: To execute the script perform similar steps as can be found at end of proto.
# Currently there are still some bugs but overall it works, it could use some further fine tuning overall is what I am trying to say
# As for the color Tuning: I'll show you when I have time