import cv2
import test
from proto import Proto

cap2 = cv2.VideoCapture(1)
ret2, frame2 = cap2.read()
prot = Proto()
            
            
print("Camera Width:", cv2.CAP_PROP_FRAME_WIDTH)
dist = prot.getDistance(frame2, cap2.get(cv2.CAP_PROP_FRAME_WIDTH), cap2.get(cv2.CAP_PROP_FRAME_HEIGHT))
       
while(dist == "N/A"):
    print("Distance not yet found.", dist)
    ret2, frame2 = cap2.read()
    dist = prot.getDistance(frame2, cap2.get(cv2.CAP_PROP_FRAME_WIDTH), cap2.get(cv2.CAP_PROP_FRAME_HEIGHT))
print("distance:", dist)
            
            
cap2.release()


test.calc(0, dist)