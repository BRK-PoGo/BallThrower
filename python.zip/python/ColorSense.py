import math

import cv2
import numpy as np
import os




class ColorTuner():
    barsWindow = 'Bars'
    hl = 'H Low'
    hh = 'H High'
    sl = 'S Low'
    sh = 'S High'
    vl = 'V Low'
    vh = 'V High'

    #To be passed by class taht calls this script
    frame = None #frame input
    screenWidth = None
    screenHeight = None


    #Colorrelated Vars
    hsv = None
    mask = None
    maskedFrame = None
    iniMask = False
    colorMask = None

    tErode = 0
    tDilate = 0
    erodeDil = []

    HSVLOW = None
    HSVHIGH = None

    def __init__(self):
        self.trackBarCreate()

    def nothing(self, x):
        pass

    def trackBarCreate(self):
        # create window for the slidebars
        cv2.namedWindow(self.barsWindow, flags=cv2.WINDOW_AUTOSIZE)

        # create the sliders
        cv2.createTrackbar(self.hl, self.barsWindow, 0, 179, self.nothing)
        cv2.createTrackbar(self.hh, self.barsWindow, 0, 179, self.nothing)
        cv2.createTrackbar(self.sl, self.barsWindow, 0, 255, self.nothing)
        cv2.createTrackbar(self.sh, self.barsWindow, 0, 255, self.nothing)
        cv2.createTrackbar(self.vl, self.barsWindow, 0, 255, self.nothing)
        cv2.createTrackbar(self.vh, self.barsWindow, 0, 255, self.nothing)

        self.resetTrackBar()


    def resetTrackBar(self):
        # set initial values for sliders
        cv2.setTrackbarPos(self.hl, self.barsWindow, 0)
        cv2.setTrackbarPos(self.hh, self.barsWindow, 179)
        cv2.setTrackbarPos(self.sl, self.barsWindow, 0)
        cv2.setTrackbarPos(self.sh, self.barsWindow, 255)
        cv2.setTrackbarPos(self.vl, self.barsWindow, 0)
        cv2.setTrackbarPos(self.vh, self.barsWindow, 255)

    def closeTrackBar(self):
        self.closeWindow(self.barsWindow)

    def closeWindow(self, window):
        cv2.destroyWindow(window)

    def passInput(self, frame, screenWidth, screenHeight):
        self.frame = frame
        self.screenWidth = screenWidth
        self.screenHeight = screenHeight



    def update(self, erosion, dilation):
        gray = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)
        self.frame = cv2.GaussianBlur(self.frame, (5, 5), 0)

        # convert to HSV from BGR
        self.hsv = cv2.cvtColor(self.frame, cv2.COLOR_BGR2HSV)


        hul = cv2.getTrackbarPos(self.hl, self.barsWindow)
        huh = cv2.getTrackbarPos(self.hh, self.barsWindow)
        sal = cv2.getTrackbarPos(self.sl, self.barsWindow)
        sah = cv2.getTrackbarPos(self.sh, self.barsWindow)
        val = cv2.getTrackbarPos(self.vl, self.barsWindow)
        vah = cv2.getTrackbarPos(self.vh, self.barsWindow)

        # make array for final values
        self.HSVLOW = np.array([hul, sal, val])
        self.HSVHIGH = np.array([huh, sah, vah])

        if(not self.iniMask):
            self.mask = cv2.inRange(self.hsv, self.HSVLOW, self.HSVHIGH)
            self.maskedFrame = cv2.bitwise_and(self.frame, self.frame, mask=self.mask)
            iniMask = True

        self.colorMask = cv2.inRange(self.hsv, self.HSVLOW, self.HSVHIGH)


        if(erosion > 0):
            self.mask = cv2.erode(self.mask, (5,5), iterations=erosion)
        if (dilation > 0):
            self.mask = cv2.dilate(self.mask, (3, 3), iterations=dilation)

        self.maskedFrame = cv2.bitwise_and(self.frame, self.frame, mask=self.mask)

        return self.maskedFrame

        #cv2.imshow('Camera', self.frame)

    def getHSVBound(self):
        return self.HSVLOW, self.HSVHIGH

    def getConutours(self):
        ret, threshold = cv2.threshold(self.mask, 0, 255, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        _, contours, _ = cv2.findContours(threshold, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

        hull = []
        for a in contours[0]:
            point = a[0]
            point = str(point)
            if(point.startswith(' ')):
                del point[0]
            point = point.split()


    def terminateColSense(self):
        cv2.destroyAllWindows()


class ColorDistance():

    yellowLow = None
    yellowHigh = None
    yErode = 0
    yDilate = 0

    pinkLow = None
    pinkHigh = None
    pErode = 0
    yDilate = 0

    frame = None
    gray = None

    distance = None


    def getContourDistance(self, frame, frameWidth, frameHeight, hsvValues, ERODIL, measureInterval):
        frameCop = cv2.GaussianBlur(np.copy(frame),(5, 5), 0)
        gray = cv2.cvtColor(frameCop, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(frameCop, cv2.COLOR_BGR2HSV)
        contoursY, yellow, contoursP, pink = self.calcContours(np.copy(frame), hsv, frameWidth, frameHeight, hsvValues, ERODIL)


        compY = self.contors2Points(contoursY)
        compP = self.contors2Points(contoursP)

        if (compY.any()):
            hullY = cv2.convexHull(compY)
            cv2.drawContours(frameCop, [hullY], -1, (255, 0, 0), 2)

            yCX, yCY = self.getContourCenter(hullY)
            #cv2.circle(frame, (pC, pCY), 5, (0, 0, 255), 3)
            outerY = self.getOuterPoints(hullY, [yCX, yCY])

        else:
            outerY = None

        if (compP.any()):
            hullP = cv2.convexHull(compP)
            cv2.drawContours(frameCop, [hullP], -1, (0, 0, 255), 2)

            pCX, pCY = self.getContourCenter(hullP)
            #cv2.circle(frameCop, (pCX, pCY), 5, (0, 0, 255), 3)
            outerP = self.getOuterPoints(hullP, [pCX, pCY])
        else:
            outerP = None

        #No additional offset
        #boxDist = self.getBoxDist(outerP, outerY)
        
        boxDist, addOffset = self.getBoxDist2(outerP, outerY)

        if (boxDist is not None):
            self.distance = 142 - boxDist - addOffset
        else:
            self.distance = "N/A"

        print("Distance from Camera to Box =", boxDist, "\nTo Robot =", self.distance, "\nAdded offset =", addOffset)

        if(self.distance is not "N/A"):
            cv2.putText(frameCop, str(self.distance), (500, 400), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.putText(frameCop, str(boxDist), (100, 400), cv2.FONT_HERSHEY_SIMPLEX,  1, (0, 255, 255), 2)

        return frameCop




    def getSpecificColMask(self, lower, upper, frame, hsv, width, height, erodeVal, dilateVal):
        colorLow = np.array(lower)
        colorHigh = np.array(upper)
        colorMask = cv2.inRange(hsv, colorLow, colorHigh)

        kernel = np.ones((5, 5), np.uint8)
        kernel2 = np.ones((3, 3), np.uint8)
        color = cv2.erode(colorMask, kernel, iterations=erodeVal)
        color = cv2.dilate(colorMask, kernel, iterations=dilateVal)
        return color

    def removeFrameCont(self, contours, frameWidth, frameHeight):
        i = 0
        while (i < len(contours)):
            area = cv2.contourArea(contours[i])
            # print('Ext: ' + str(area))
            if ((area <= (frameWidth * frameHeight) and area >= 30000) or area <= 150):
                # print(area)
                # print("\n" + str(area))
                # print('EXCEPTION FOUND')
                npCont = np.array(contours)
                # contours.remove(contours[i])
                del contours[i]
                i = i - 1
            i += 1
        return contours


    def calcContours(self, frame, hsv, width, height, HSVBOUNDS, ERODEDIL):

        yellowLow = HSVBOUNDS[0]
        yellowHigh = HSVBOUNDS[1]

        yellowErode = ERODEDIL[0]
        yellowDil = ERODEDIL[1]

        yellow = self.getSpecificColMask(yellowLow, yellowHigh, frame, hsv, width, height, yellowErode, yellowDil)

        pinkLow = HSVBOUNDS[2]
        pinkHigh = HSVBOUNDS[3]

        pinkErode = ERODEDIL[2]
        pinkDil = ERODEDIL[3]

        pink = self.getSpecificColMask(pinkLow, pinkHigh, frame, hsv, width, height, pinkErode, pinkDil)

        ret, threshold = cv2.threshold(yellow, 100, 255, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        _, contoursY, _ = cv2.findContours(threshold, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

        ret, threshold = cv2.threshold(pink, 100, 255, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        _, contoursP, _ = cv2.findContours(threshold, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

        if (len(contoursY) > 0):
            contoursY = self.removeFrameCont(contoursY, width, height)
        if (len(contoursP) > 0):
            contoursP = self.removeFrameCont(contoursP, width, height)

        return (contoursY, yellow, contoursP, pink)


    def getDistance(self, pixlwidth, actLength):
        focal = 559.542
        # actLength = 35
        t1 = (pixlwidth * focal)
        t2 = t1 / actLength

        return (int)((actLength * focal) / pixlwidth)

    def contors2Points(self, conts):
        pt = []
        for cont in conts:
            for p in cont:
                pt.append(p)
        # print('internal single: ' + str(pt))
        return np.int0(pt)

    def getContourCenter(self, contour):
        if not contour.any():
            return None
        M = cv2.moments(contour)
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        # print("cX = " + str(cX) + " | cY = " + str(cY))
        return (cX, cY)

    def getOuterPoints(self, contour, center):
        # print("Center:\t" + str(center))
        points = cv2.convexHull(contour, clockwise=True)
        # print("Points: " + str(points))

        uLeft = []
        uRight = []
        lLeft = []
        lRight = []

        for point in points:
            tPoint = point.tolist()[0]
            # print("orientation tPoint: " + str(tPoint))
            if (tPoint[0] < center[0]):
                if (tPoint[1] < center[1]):
                    uLeft.append(tPoint)
                else:
                    lLeft.append(tPoint)
            else:
                if (tPoint[1] < center[1]):
                    uRight.append(tPoint)
                else:
                    lRight.append(tPoint)


        if (uLeft.__len__() > 0):
            upperLeft = uLeft[0]
        else:
            upperLeft = None

        if (lLeft.__len__() > 0):
            lowerLeft = lLeft[0]
        else:
            lowerLeft = None

        if (uRight.__len__() > 0):
            upperRight = uRight[0]
        else:
            upperRight = None

        if (lRight.__len__() > 0):
            lowerRight = lRight[0]
        else:
            lowerRight = None

        i = 1
        while (i < uLeft.__len__()):
            tPoint = uLeft[i]
            # print('upperLeft: ' + str(tPoint))
            if (self.getDist(tPoint, center) > self.getDist(upperLeft, center)):
                upperLeft = tPoint
            i += 1

        i = 1
        while (i < lLeft.__len__()):
            tPoint = lLeft[i]
            # print('lowerLeft: ' + str(tPoint))
            if (self.getDist(tPoint, center) > self.getDist(lowerLeft, center)):
                lowerLeft = tPoint
            i += 1

        i = 1
        while (i < uRight.__len__()):
            tPoint = uRight[i]
            # print('upperRight: ' + str(tPoint))
            if (self.getDist(tPoint, center) > self.getDist(upperRight, center)):
                upperRight = tPoint
            i += 1

        i = 1
        while (i < lRight.__len__()):
            tPoint = lRight[i]
            # print('lowerRight: ' + str(tPoint))
            if (self.getDist(tPoint, center) > self.getDist(lowerRight, center)):
                lowerRight = tPoint
            i += 1

        return [upperLeft, upperRight, lowerLeft, lowerRight]

    def getDist(self, point1, point2):
        # print('Point1: ' + str(point1))
        # print('point2: ' + str(point2))


        return (math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2))

    def drawConts(self, frame, contours, color):
        cv2.drawContours(frame, contours, -1, color, 6)

    def getContourLength(self,outerPoints):
        [uL, uR, lL, lR] = outerPoints

        length1 = self.getDist(uL, uR)
        length2 = self.getDist(lL, lR)

        height1 = self.getDist(lL, uL)
        height2 = self.getDist(lR, uR)

        return length1, height1

    def getBoxDist(self,outerP, outerY):
        # Yellow-Side: 20/12.5 = 1.6
        # pink-Side: 34.5/12.5 = 2.76
        if (outerY is not None and None not in outerY):
            sideLengthY, sideWdithY = self.getContourLength(outerY)
            yRatio = sideLengthY / sideWdithY
            #print("yRatio => " + str(yRatio))
        else:
            yRatio = 0
        if (outerP is not None and None not in outerP):
            sideLengthP, sideWdithP = self.getContourLength(outerP)
            pRatio = sideLengthP / sideWdithP
            #print("pRatio => " + str(pRatio))
        else:
            pRatio = None
            
        if (outerY is not None and yRatio is not None and (yRatio >= 1.5 and yRatio <= 1.9)):
            actualLength = 20
            distance = self.getDistance(sideLengthY, actualLength)

            # Offset (double check focallength)
            distance += 9

            # Offset to center of box
            distance += 17

            # print("Length: " + str(sideLength))
            #print("Distance: " + str(distance))
            return distance
        elif (outerP is not None and pRatio is not None and (pRatio >= 2.5 and pRatio <= 3.1)):
            actualLength = 35
            distance = self.getDistance(sideLengthP, actualLength)

            # Offset (double check focallength)
            distance += 11

            # Offset to center of box
            distance += 10

            #print("Distance: " + str(distance))
            return distance
        return None

    def getBoxDist2(self,outerP, outerY):
        # Yellow-Side: 20/12.5 = 1.6
        # pink-Side: 34.5/12.5 = 2.76
        if (outerY is not None and None not in outerY):
            sideLengthY, sideWdithY = self.getContourLength(outerY)
            yRatio = sideLengthY / sideWdithY
            #print("yRatio => " + str(yRatio))
        else:
            yRatio = 0
        if (outerP is not None and None not in outerP):
            sideLengthP, sideWdithP = self.getContourLength(outerP)
            pRatio = sideLengthP / sideWdithP
            #print("pRatio => " + str(pRatio))
        else:
            pRatio = None
            
        if (outerY is not None and yRatio is not None and (yRatio >= 1.5 and yRatio <= 1.9)):
            actualLength = 20
            distance = self.getDistance(sideLengthY, actualLength)

            # Offset (double check focallength)
            distance += 9

            # Offset to center of box
            distance += 17

            # print("Length: " + str(sideLength))
            #print("Distance: " + str(distance))
            return (distance, 0)
        elif (outerP is not None and pRatio is not None and (pRatio >= 2.5 and pRatio <= 3.1)):
            actualLength = 35
            distance = self.getDistance(sideLengthP, actualLength)

            # Offset (double check focallength)
            distance += 7

            # Offset to center of box
            distance += 10

            #print("Distance: " + str(distance))
            return (distance, 2)
        return (None, None)

    def getTargetDistance(self):
        return self.distance