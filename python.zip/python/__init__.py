from CVSupport import CVSupport
import cv2
from ColorSense import ColorTuner, ColorDistance
import numpy as np





#Tuning Process
cap = cv2.VideoCapture(1)
ret, frame = cap.read()
width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)  # float
height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)  # float
eroCount = 0
dilCount = 0

colSens = None


#Array that keeps all the HSV values in it
#Each entry consists of 3 values. Order: [yelLow, yelHigh, redLow, redHigh]
hsvValues = []
erodDil = []

print("Process started. Tuning required?:\ny/n?")
while True:
    ret, frame = cap.read()
    cv2.imshow("frame", frame)

    if cv2.waitKey(1) & 0xFF == ord('n'):
        #ValueError('Process stopped')
        hsvValues = [np.array([15, 145, 147]), np.array([31, 255, 210]), np.array([85, 149, 134]), np.array([179, 255, 255])]
        erodDil = [2,2, 0, 2]

        breakq


    if cv2.waitKey(1) & 0xFF == ord('y'):
        tuned = False
        colSens = ColorTuner()
        print("Tuning process started:\nUse mouse input on Trackbar to adjust HSV values.\nPress 'd' for dilation, "
              "'e' for erosion, \n'n' when you want to tune the next color and 'q' to quit\n")
        colorsTuned = 0
        while(colorsTuned < 2):
            ret, frame = cap.read()
            colSens.passInput(frame, width, height)
            mask = colSens.update(eroCount, dilCount)
            cv2.imshow("Mask", mask)
            if cv2.waitKey(1) & 0xFF == ord('n'):
                colorsTuned += 1
                if(colorsTuned < 2):
                    print("Tuning process for next color started:\nUse mouse input on Trackbar to adjust HSV values.\nPress 'd' for dilation, "
                        "'e' for erosion, \n'n' when you want to tune the next color and 'q' to quit\n")
                    colSens.resetTrackBar()
                    hsvValues.append(np.copy(colSens.HSVLOW))
                    hsvValues.append(np.copy(colSens.HSVHIGH))
                    erodDil.append(eroCount)
                    erodDil.append(dilCount)
                    eroCount = 0
                    dilCount = 0
                else:
                    hsvValues.append(np.copy(colSens.HSVLOW))
                    hsvValues.append(np.copy(colSens.HSVHIGH))
                    erodDil.append(eroCount)
                    erodDil.append(dilCount)
                    colSens.closeWindow("Mask")
                    print("HSV-Bounds: " + str(hsvValues) + "\n")
                    print("Erosion Dilation: " + str(erodDil) + "\n")
                    break
            if cv2.waitKey(1) & 0xFF == ord('e'):
                eroCount += 1
                print("Erosion/Dilanation => " + str(eroCount) + "/" + str(dilCount))
            if cv2.waitKey(1) & 0xFF == ord('d'):
                dilCount += 1
                print("Erosion/Dilation => " + str(eroCount) + "/" + str(dilCount))
            if cv2.waitKey(1) & 0xFF == ord('r') and eroCount > 0:
                eroCount -= 1
                print("Erosion/Dilation => " + str(eroCount) + "/" + str(dilCount))
            if cv2.waitKey(1) & 0xFF == ord('f') and dilCount > 0:
                dilCount -= 1
                print("Erosion/Dilation => " + str(eroCount) + "/" + str(dilCount))


            if cv2.waitKey(5) & 0xFF == ord('q'):
                colSens.terminateColSense()
                ValueError('Process stopped')




print("HSV Values: ")
print("Color1: lower/upper: " + str(hsvValues[0]) +"/" + str(hsvValues[1]) + "\tDilation/erosion: " + str(erodDil[0]) + "/" + str(erodDil[1]))
print("Color2: lower/upper: " + str(hsvValues[2]) +"/" + str(hsvValues[3]) + "\tDilation/erosion: " + str(erodDil[2]) + "/" + str(erodDil[3]))


cv2.destroyAllWindows()
colDist = ColorDistance()
cvSup = CVSupport()

target = cv2.imread('qrExample.png')

matchThreshold = 15

while(True):
    frame = frame = cvSup.getVideoFrame()

    BF, matches = cvSup.findMatch("SIFT", frame)
    cv2.imshow("BF", BF)
    display = colDist.getContourDistance(frame, width, height, hsvValues, erodDil, 3)
    if(len(matches) >= matchThreshold):
        distance = colDist.getTargetDistance()
        cv2.putText(display, "Box detected", (230, 450), cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
    else:
        distance = "N/A"

    cv2.imshow("Display", display)
    print("Distance Calculation: " + str(distance))

    if cv2.waitKey(5) & 0xFF == ord('q'):
        break

cvSup.terminate()
cv2.destroyAllWindows()
cap.release()


"""
# Initilaize webcam



#Start Matchfijnding Process


k = 0




bf = cv2.BFMatcher()
#Main loop
while(True):
    frame = cvSup.getVideoFrame()
    Sift = np.copy(frame)
    Surf = np.copy(frame)

    BF = cvSup.findMatch("SIFT", frame)

    cv2.imshow("BF", BF)

    if cv2.waitKey(5) & 0xFF == ord('q'):
        break




"""





