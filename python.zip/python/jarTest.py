import subprocess

file1 = "distance.txt"
file2 = "angles.txt"
    
distanceInt = str(50)
    
distance = open(file1, 'w')
distance.write(distanceInt)
distance.close()
    
subprocess.call(['java', '-jar', 'executableANN.jar'])
    
angles = open(file2, 'r')
angString = angles.readline()
angList = angString.split(" ")
angListAct = [0, angList[2], angList[0], angList[1]]
angles.close()

for i in range(len(angListAct)):
    print(str(angListAct[i]))